MY HISAB KHATA — ANDROID WEBVIEW PROJECT
========================================

WHAT IS INCLUDED
- app/src/main/assets/index.html: the existing My Hisab Khata app packaged locally.
- Android WebView wrapper with JavaScript and localStorage enabled.
- Android system file picker for restoring a JSON backup.
- Android system Save As dialog for exporting a JSON backup.
- Internet permission is included for future online-sync integration.

IMPORTANT HONEST LIMITATIONS
- This ZIP is Android Studio source code, NOT a compiled APK.
- A cloud sync server/account is NOT configured. The app currently works offline and stores data locally on this device. Online sync needs a secure backend, user login, conflict handling, and privacy/security setup.
- The local automatic backups remain in the app's browser storage (up to 7 daily snapshots). They are not a substitute for downloading a backup file.
- Android Studio build has not been run in this environment because Android SDK/Gradle build tools are not available here.

BUILD AN APK (FREE)
1. Install Android Studio on a Windows/Mac/Linux computer.
2. Extract My_Hisab_Khata_Android_Project.zip.
3. In Android Studio choose File > Open, then select the extracted MyHisabKhataAndroid folder (the one containing settings.gradle).
4. Allow Android Studio to download the Gradle/Android plugins and SDK components when prompted. JDK 17 is recommended for Android Gradle Plugin 8.7.x.
5. Wait for Gradle Sync to finish. If prompted, install Android SDK Platform 35 and Build Tools through SDK Manager.
6. For a test APK choose Build > Build Bundle(s) / APK(s) > Build APK(s).
7. The debug APK is normally created at app/build/outputs/apk/debug/app-debug.apk.
8. Copy the APK to your Android phone and install it. You may need to allow installation from that file manager/browser. Only install APKs you trust.

FEATURES IN THE EMBEDDED APP
Bengali/English labels as provided by the existing HTML; customer and supplier records/ledgers; buy/sale; stock; due/payments; printable invoice; P&L/balance-sheet area; JSON backup/restore; local auto-save and up to 7 daily local auto-backups.

DATA SAFETY
The data is stored locally in WebView localStorage. Clearing app data or uninstalling may erase it. Export a JSON backup regularly and store it somewhere safe. Do not treat local storage as cloud backup.

PACKAGE ID: com.myhisabkhata.app
VERSION: 1.0.0
MINIMUM ANDROID: Android 6.0 (API 23)

CLOUD APK BUILD (NO ANDROID STUDIO NEEDED ON YOUR PC)
1. Create/sign in to a GitHub account at https://github.com
2. Create a NEW repository (e.g. my-hisab-khata). Set it to Private if preferred.
3. Upload the CONTENTS of this MyHisabKhataAndroid folder into the repository root (not the outer folder itself). Ensure .github/workflows/build-apk.yml is included.
4. Open the repository's Actions tab and select “Build My Hisab Khata APK”.
5. Press “Run workflow” (if shown), then open the running/completed workflow.
6. When successful, download the artifact named “My-Hisab-Khata-debug-APK”. Extract it to get app-debug.apk.
7. Transfer app-debug.apk to your Android phone and install it. You may need to allow “Install unknown apps” for the app used to open the APK.

IMPORTANT: This builds a DEBUG/test APK, not a Play Store release. Actual cloud login/sync is NOT implemented yet; current records are stored locally on the device. Keep JSON backups. GitHub UI labels may vary.
